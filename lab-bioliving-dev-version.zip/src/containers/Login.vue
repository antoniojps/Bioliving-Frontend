<template>
  <el-row :gutter="24" style="margin-left:auto;margin-right:auto;">
    <h1>Login</h1>
  </el-row>
</template>

<script>

</script>

<style lang="scss">
  @import '../assets/scss/styles.scss';


</style>

