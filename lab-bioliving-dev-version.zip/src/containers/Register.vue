<template>
  <div>
    <el-row :gutter="24" style="margin-left:auto;margin-right:auto;">
      <h1>Register</h1>
    </el-row>
  </div>
</template>

<script>
</script>

<style lang="scss">
  @import '../assets/scss/styles.scss';
</style>

